﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Телефонная_книга
{
    class PhoneBook
    {
        List<Contact> ListContacts;
        public List<Contact> _ListContacts 
        {
            get
            {
                return ListContacts;
            }
        }
        public PhoneBook () 
        {
            ListContacts = new List<Contact>( );
        }
        public void AddContact (string name, string phone)
        {
            ListContacts.Add(new Contact(name, phone));
        }
        public void AddContact (Contact contact)
        {
            ListContacts.Add(contact);
        }
        public void RemoveContact (string name, string phone)
        {
            for (int i=0; i<ListContacts.Count();i++ )
            {
                if ( ListContacts[i].Name == name && ListContacts [ i ].Phone == phone )
                {
                    ListContacts.RemoveAt(i);
                }
            }
        }
        public Contact SearchContact (string name)
        {
            foreach (Contact contact in ListContacts)
            {
                if (contact.Name==name) 
                {
                    return contact;
                }
            }
            return null;
        }
        public Contact SearchContact (string name,string phone)
        {
            foreach ( Contact contact in ListContacts )
            {
                if (contact.Phone==phone)
                {
                    return contact;
                }
            }
            return null;
        }
    }
}
