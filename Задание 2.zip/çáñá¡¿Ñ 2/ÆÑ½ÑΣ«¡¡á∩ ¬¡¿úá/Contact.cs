﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Телефонная_книга
{
    class Contact
    {
        string name, phone;
        public string Name 
        { 
            get 
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        public string Phone 
        { 
            get 
            {
                return phone;
            }
            set
            {
                phone = value;
            }
        }
        public Contact (string name, string phone)
        {
            this.name = name;
            this.phone = phone;
        }
    }
}
