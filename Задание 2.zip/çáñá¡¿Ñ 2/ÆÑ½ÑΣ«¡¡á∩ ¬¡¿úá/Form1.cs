﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Телефонная_книга
{
    public partial class Form1 :Form
    {
        PhoneBook phoneBook;
        const string FILENAME = "contacts2.txt";
        public Form1 ()
        {
            InitializeComponent( );
            phoneBook = new PhoneBook( );
            PhoneBookLoader.Load(phoneBook, FILENAME);
            if ( phoneBook._ListContacts.Count( ) == 0 )
            {
                button2.Enabled = false;
                MessageBox.Show($"Файл {FILENAME} пустой");
            }
            Set_ListBox1( );
        }
        private void Set_ListBox1 () 
        {
            listBox1.Items.Clear( );
            int i = 0;
            foreach ( Contact contact in phoneBook._ListContacts )
            {
                listBox1.Items.Add(contact.Name);
                i++;
            }
        }
        private void Check_Name (string name, ref string messag) 
        {
            foreach (char ch in name) 
            {
                if (char.IsDigit(ch)) 
                {
                    messag = "В имени может быть только буквы";
                    return;
                }
            }
        }
        private void Check_Phone (string phone, ref string messag)
        {
            if (phone.Length==14) 
            {
                for (int i=0; i<phone.Length;i++ ) 
                {
                    if (!(char.IsDigit(phone[i]) || i==0 || i==4 || i==8 || i==11)) 
                    {
                        messag = "В номере не должно быть букв";
                        return;
                    } 
                }
                if ( phone [ 0 ] != '(' )
                {
                    messag = "Неправильно ведён номер\n(***)***-**-**";
                    return;
                }
                if ( phone [ 4 ] != ')' )
                {
                    messag = "Неправильно ведён номер\n(***)***-**-**";
                    return;
                }
                if ( phone [ 8 ] != '-' || phone [ 11 ] != '-')
                {
                    messag = "Неправильно ведён номер\n(***)***-**-**";
                    return;
                }
            }
            else
            {
                messag = "Неправильно ведён номер\n(***)***-**-**";
            }
        }
        private void listBox1_SelectedIndexChanged (object sender, EventArgs e)
        {
            textBox1.Text = phoneBook._ListContacts [ listBox1.SelectedIndex ].Name;
            textBox2.Text = phoneBook._ListContacts [ listBox1.SelectedIndex ].Phone;
        }

        private void Exit (object sender, EventArgs e)
        {
            this.Close( );
        }

        private void AddContact (object sender, EventArgs e)
        {
            string messag = "";
            Check_Name(textBox1.Text, ref messag);
            Check_Phone(textBox2.Text, ref messag);
            if ( messag == "" )
            {
                Contact contact = phoneBook.SearchContact(textBox1.Text, textBox2.Text);
                if ( contact == null )
                {
                    phoneBook.AddContact(textBox1.Text, textBox2.Text);
                    MessageBox.Show("Контакт добавлен");
                    textBox1.Text = "";
                    textBox2.Text = "";
                    Set_ListBox1( );
                    if ( phoneBook._ListContacts.Count( ) > 0 )
                    {
                        button2.Enabled = true;
                    }
                }
                else
                {
                    MessageBox.Show("Такой контак есть");
                }
            }
            else
            {
                MessageBox.Show(messag);
            }
        }

        private void RemoveContact (object sender, EventArgs e)
        {
            string messag = "";
            Check_Name(textBox1.Text, ref messag);
            Check_Phone(textBox2.Text, ref messag);
            if ( messag == "" )
            {
                phoneBook.RemoveContact(textBox1.Text, textBox2.Text);
                MessageBox.Show("Контакт удален");
                textBox1.Text = "";
                textBox2.Text = "";
                Set_ListBox1( );
                if ( phoneBook._ListContacts.Count( ) == 0 )
                {
                    button2.Enabled = false;
                }
            }
            else
            {
                MessageBox.Show(messag);
            }
        }

        private void SearchContact (object sender, EventArgs e)
        {
            string messag = "";
            Check_Name(textBox1.Text, ref messag);
            if ( messag == "" )
            {
                Contact contact = phoneBook.SearchContact(textBox1.Text);
                if ( contact != null )
                {
                    textBox2.Text = contact.Phone;
                }
                else
                {
                    MessageBox.Show("Контакт не найден");
                }
            }
            else
            {
                MessageBox.Show(messag);
            }
        }

        private void Save (object sender, EventArgs e)
        {
            PhoneBookLoader.Save(phoneBook, FILENAME);
            MessageBox.Show("Файл сохранен");
        }
    }
}
